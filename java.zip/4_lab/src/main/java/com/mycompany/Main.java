package com.mycompany;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static int getNumberFromConsole(Scanner scanner, String message) {
        int n;
        do {
            System.out.print(message);
            while (!scanner.hasNextInt()) {
                System.out.print("Некорректный ввод. Введите целое положительное число: ");
                scanner.next();
            }
            n = scanner.nextInt();
        } while (n <= 0);

        return n;
    }

    public static double getDoubleFromConsole(Scanner scanner, String message) {
        double n;
        do {
            System.out.print(message);
            while (!scanner.hasNextDouble()) {
                System.out.print("Некорректный ввод. Введите вещественное число: ");
                scanner.next();
            }
            n = scanner.nextDouble();
        } while (n <= 0);

        return n;
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Ввод размера массива с проверкой корректности данных
        int size = getNumberFromConsole(scanner, "Введите размер массива (положительное целое число): ");

        // Ввод диапазона случайных значений с проверкой корректности данных
        double x, y;
        do {
            x = getDoubleFromConsole(scanner, "Введите минимальное значение диапазона (x): ");
            y = getDoubleFromConsole(scanner, "Введите максимальное значение диапазона (y): ");

            if (x >= y) {
                System.out.println("Ошибка: нижняя граница должна быть меньше верхней границы.");
            }
        } while (x >= y);
        scanner.close();

        // Создание и заполнение массива случайными вещественными числами
        double[] array = new double[size];
        for (int i = 0; i < size; i++) {
            if (random.nextBoolean())
                array[i] = x + (y - x) * random.nextDouble(1); // генерация значения от x до y
            else
                array[i] = -y + (-x + y) * random.nextDouble(1); // генерация значения от -y до -x
        }

        // Вычисление суммы элементов массива и среднего арифметического значения
        double sum = 0;
        for (double num : array) {
            sum += num;
        }
        double average = sum / size;

        // Вывод массива, суммы и среднего арифметического значения
        System.out.println("Исходный массив:");
        for (double num : array) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.println("Сумма элементов массива: " + sum);
        System.out.println("Среднее арифметическое значение массива: " + average);
    }
}