package com.mycompany;

import javax.swing.*;
import java.util.Random;

public class Main {

    public static int getUserInputNumber(String message) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(message);
                int value = Integer.parseInt(input);
                if (value >= 1) {
                    return value;
                } else {
                    JOptionPane.showMessageDialog(null, "Введите значение в диапазоне от " + 1 + " до " + Integer.MAX_VALUE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Введите корректное целое число.");
            }
        }
    }

    public static double getUserInputDouble(String message, double minValue) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(message);
                double value = Double.parseDouble(input);
                if (value >= minValue) {
                    return value;
                } else {
                    JOptionPane.showMessageDialog(null, "Введите значение в диапазоне от " + minValue + " до " + Double.POSITIVE_INFINITY);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Введите корректное число.");
            }
        }
    }

    public static String matrixToString(double[][] matrix) {
        StringBuilder sb = new StringBuilder();
        for (double[] row : matrix) {
            for (double value : row) {
                sb.append(String.format("%.2f", value)).append("\t");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        // Получение размера матрицы от пользователя
        int size = getUserInputNumber("Введите размер матрицы (положительное целое число):");

        // Получение диапазона значений от пользователя
        double x = getUserInputDouble("Введите минимальное значение диапазона:", Double.NEGATIVE_INFINITY);
        double y = getUserInputDouble("Введите максимальное значение диапазона (должно быть больше минимального):", x);

        // Генерация матриц
        Random random = new Random();
        double[][] matrixA = new double[size][size];
        double[][] matrixB = new double[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (random.nextBoolean()) {
                    matrixA[i][j] = x + (y - x) * random.nextDouble(1);
                    matrixB[i][j] = x + (y - x) * random.nextDouble(1);
                } else {
                    matrixA[i][j] = -y + (-x + y) * random.nextDouble(1); // генерация значения от -y до -x
                    matrixB[i][j] = -y + (-x + y) * random.nextDouble(1); // генерация значения от -y до -x
                }
            }
        }

        // Вычисление произведения матриц
        double[][] resultMatrix = new double[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int k = 0; k < size; k++) {
                    resultMatrix[i][j] += matrixA[i][k] * matrixB[k][j];
                }
            }
        }

        // Вывод матриц
        StringBuilder answer = new StringBuilder();
        answer.append("Матрица A:\n").append(matrixToString(matrixA)).append("\n");
        answer.append("Матрица B:\n").append(matrixToString(matrixB)).append("\n");
        answer.append("Результат произведения A*B:\n").append(matrixToString(resultMatrix)).append("\n");

        JOptionPane.showMessageDialog(null, answer);
    }
}