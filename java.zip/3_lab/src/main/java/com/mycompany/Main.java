package com.mycompany;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static int getNumberFromConsole(Scanner scanner, String message){
        int n;
        do {
            System.out.print(message);
            while (!scanner.hasNextInt()) {
                System.out.print("Некорректный ввод. Введите целое положительное число: ");
                scanner.next();
            }
            n = scanner.nextInt();
        } while (n <= 0);

        return n;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Ввод размера массива с проверкой корректности данных
        int size = getNumberFromConsole(scanner, "Введите размер массива (положительное целое число): ");

        // Создание и заполнение массива случайными числами
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(100); // случайные числа от 0 до 99
        }

        // Создание массива с обратным порядком элементов
        int[] reversedArray = new int[size];
        for (int i = 0; i < size; i++) {
            reversedArray[i] = array[size - 1 - i];
        }

        // Вывод исходного и перевернутого массива
        System.out.println("Исходный массив:");
        for (int i = 0; i < size; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        System.out.println("Перевернутый массив:");
        for (int i = 0; i < size; i++) {
            System.out.print(reversedArray[i] + " ");
        }
    }
}