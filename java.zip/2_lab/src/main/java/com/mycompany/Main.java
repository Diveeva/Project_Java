package com.mycompany;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static int getNumberFromConsole(Scanner scanner, String message){
        int n;
        do {
            System.out.print(message);
            while (!scanner.hasNextInt()) {
                System.out.print("Некорректный ввод. Введите целое положительное число: ");
                scanner.next();
            }
            n = scanner.nextInt();
        } while (n <= 0);

        return n;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Ввод размеров матрицы с проверкой корректности данных
        int rows = getNumberFromConsole(scanner, "Введите количество строк (положительное целое число): ");
        int cols = getNumberFromConsole(scanner, "Введите количество столбцов (положительное целое число): ");

        // Создание и заполнение матрицы случайными целыми числами
        int[][] matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = random.nextInt(100); // случайные числа от 0 до 99
            }
        }

        // Вывод исходной матрицы
        System.out.println("Исходная матрица:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }

        // Нахождение максимального и минимального значения
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (matrix[i][j] > max) {
                    max = matrix[i][j];
                }
                if (matrix[i][j] < min) {
                    min = matrix[i][j];
                }
            }
        }

        // Вычисление суммы элементов для каждой строки и столбца
        int[] rowSums = new int[rows];
        int[] colSums = new int[cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                rowSums[i] += matrix[i][j];
                colSums[j] += matrix[i][j];
            }
        }

        // Вывод результатов
        System.out.println("Максимальное значение: " + max);
        System.out.println("Минимальное значение: " + min);

        System.out.println("Суммы элементов для каждой строки:");
        for (int i = 0; i < rows; i++) {
            System.out.println("Строка " + (i + 1) + ": " + rowSums[i]);
        }

        System.out.println("Суммы элементов для каждого столбца:");
        for (int j = 0; j < cols; j++) {
            System.out.println("Столбец " + (j + 1) + ": " + colSums[j]);
        }
    }
}