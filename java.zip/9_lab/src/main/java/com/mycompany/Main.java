package com.mycompany;

import javax.swing.*;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class Main {

    public static int getUserInputNumber(String message, int minValue, int maxValue) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(message);
                int value = Integer.parseInt(input);
                if (value >= minValue && value <= maxValue) {
                    return value;
                } else {
                    JOptionPane.showMessageDialog(null, "Введите значение в диапазоне от " + minValue + " до " + maxValue);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Введите корректное целое число.");
            }
        }
    }

    public static void main(String[] args) {
        // Получение года от пользователя
        int year = getUserInputNumber("Введите год (1900-2100):", 1900, 2100);

        // Получение месяца от пользователя
        int month = -1;

        String[] months = {"Янв.", "Фев.", "Март", "Апр.", "Май.", "Июн.", "Июл.", "Авг.", "Сент.", "Окт.", "Нояб.", "Дек."};
        do {
            String input = JOptionPane.showInputDialog("Введите месяц (1-12 или Янв.-Дек.):");
            try {
                int monthCheck = Integer.parseInt(input);
                if (monthCheck >= 1 && monthCheck <= 12) {
                    month = monthCheck;
                }
            } catch (NumberFormatException e) {
                for (int i = 0; i < months.length; i++) {
                    if (months[i].equalsIgnoreCase(input)) {
                        month = i + 1;
                    }
                }
            }
            if (month == -1)
                JOptionPane.showMessageDialog(null, "Введите корректное значение месяца (1-12 или Янв.-Дек.).");
        } while (month < 0);

        // Генерация и отображение календаря
        LocalDate date = LocalDate.of(year, month, 1);
        StringBuilder calendar = new StringBuilder();

        // Заголовок календаря
        calendar.append(" ").append(date.getMonth().getDisplayName(TextStyle.FULL_STANDALONE, Locale.of("ru"))).append(" ").append(year).append("\n");
        calendar.append(" Пн\t Вт\t Ср\t Чт\t Пт\t Сб\t Вс\n");

        // Вычисление первого дня недели
        int firstDayOfWeek = date.getDayOfWeek().getValue();

        // Добавление пустых ячеек до первого дня месяца
        calendar.append("     \t".repeat(Math.max(0, firstDayOfWeek - 1)));

        // Заполнение календаря днями месяца
        int daysInMonth = date.lengthOfMonth();
        for (int day = 1; day <= daysInMonth; day++) {
            if (day < 10) calendar.append(" ");
            calendar.append(String.format("%3s\t", day));
            if ((day + firstDayOfWeek - 1) % 7 == 0) {
                calendar.append("\n");
            }
        }

        // Вывод календаря в диалоговом окне
        JOptionPane.showMessageDialog(null, calendar);
    }
}