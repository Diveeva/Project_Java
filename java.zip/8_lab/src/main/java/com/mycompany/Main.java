package com.mycompany;

import javax.swing.*;
import java.util.Random;

public class Main {
    public static int getUserInputNumber(String message, int minValue, int maxValue) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(message);
                int value = Integer.parseInt(input);
                if (value >= minValue && value <= maxValue) {
                    return value;
                } else {
                    JOptionPane.showMessageDialog(null, "Введите значение в диапазоне от " + minValue + " до " + maxValue);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Введите корректное целое число.");
            }
        }
    }

    public static void main(String[] args) {
        // Получение диапазона чисел от пользователя
        int minValue = getUserInputNumber("Введите минимальное значение диапазона (целое число):", Integer.MIN_VALUE, Integer.MAX_VALUE);
        int maxValue = getUserInputNumber("Введите максимальное значение диапазона (целое число, больше минимального):", minValue + 1, Integer.MAX_VALUE);

        // Генерация случайного числа в заданном диапазоне
        Random random = new Random();
        int targetNumber = random.nextInt(maxValue - minValue + 1) + minValue;

        // Игра в угадывание числа
        boolean guessed = false;
        while (!guessed) {
            String input = JOptionPane.showInputDialog("Угадайте число между " + minValue + " и " + maxValue + " (или введите 'Сдаюсь!' для выхода):");

            if (input == null || input.equalsIgnoreCase("Сдаюсь!")) {
                JOptionPane.showMessageDialog(null, "Вы сдались! Загаданное число было: " + targetNumber);
                break;
            }

            try {
                int guess = Integer.parseInt(input);
                if (guess < targetNumber) {
                    JOptionPane.showMessageDialog(null, "Загаданное число больше.");
                } else if (guess > targetNumber) {
                    JOptionPane.showMessageDialog(null, "Загаданное число меньше.");
                } else {
                    JOptionPane.showMessageDialog(null, "Поздравляем! Вы угадали число: " + targetNumber);
                    guessed = true;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Введите корректное целое число.");
            }
        }
    }
}