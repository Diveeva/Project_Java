package com.mycompany;

import javax.swing.*;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static int getNumberFromConsole(Scanner scanner, String message) {
        int n;
        do {
            System.out.print(message);
            while (!scanner.hasNextInt()) {
                System.out.print("Некорректный ввод. Введите целое положительное число: ");
                scanner.next();
            }
            n = scanner.nextInt();
        } while (n <= 0);

        return n;
    }

    public static double getDoubleFromConsole(Scanner scanner, String message) {
        double n;
        do {
            System.out.print(message);
            while (!scanner.hasNextDouble()) {
                System.out.print("Некорректный ввод. Введите вещественное число: ");
                scanner.next();
            }
            n = scanner.nextDouble();
        } while (n <= 0);

        return n;
    }

    public static String arrayToString(double[] array) {
        StringBuilder sb = new StringBuilder();
        for (double value : array) {
            sb.append(String.format("%.2f", value)).append("\t");
        }
        sb.append("\n");
        return sb.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ввод размера массивов
        int n = getNumberFromConsole(scanner, "Введите размер массивов: ");

        // Ввод диапазона значений
        double x, y;
        do {
            x = getDoubleFromConsole(scanner, "Введите минимальное значение диапазона (x): ");
            y = getDoubleFromConsole(scanner, "Введите максимальное значение диапазона (y): ");

            if (x >= y) {
                System.out.println("Ошибка: нижняя граница должна быть меньше верхней границы.");
            }
        } while (x >= y);
        scanner.close();

        // Создание и заполнение массивов случайными значениями
        double[] firstArray = new double[n];
        double[] secondArray = new double[n];
        double[] sumArray = new double[n];

        Random random = new Random();

        for (int i = 0; i < n; i++) {
            if (random.nextBoolean()) {
                firstArray[i] = x + (y - x) * random.nextDouble(1); // генерация значения от x до y
                secondArray[i] = x + (y - x) * random.nextDouble(); // генерация значения от x до y
            } else {
                firstArray[i] = -y + (-x + y) * random.nextDouble(1); // генерация значения от -y до -x
                secondArray[i] = -y + (-x + y) * random.nextDouble(1); // генерация значения от -y до -x
            }
            sumArray[i] = firstArray[i] + secondArray[i];
        }

        // Формирование строк для вывода массивов
        StringBuilder answer = new StringBuilder("Массив 1: ").append(arrayToString(firstArray))
                .append("Массив 2: ").append(arrayToString(secondArray))
                .append("Суммарный массив: ").append(arrayToString(sumArray));

        // Вывод массивов в диалоговом окне
        JOptionPane.showMessageDialog(null, answer);
    }
}