package com.mycompany;

import javax.swing.*;

public class Main {
    public static double getUserInputDouble(String message) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(message);
                double value = Double.parseDouble(input);
                if (value > 0) {
                    return value;
                } else {
                    JOptionPane.showMessageDialog(null, "Введите значение больше " + (double) 0 + " и меньше или равно " + Double.POSITIVE_INFINITY);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Введите корректное число.");
            }
        }
    }

    public static void main(String[] args) {
        // Получение выбора пользователя (площадь или длина окружности)
        String[] options = {"Площадь", "Длина окружности"};
        int choice = JOptionPane.showOptionDialog(null, "Выберите цель расчета:", "Выбор расчета",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        // Проверка, что пользователь сделал выбор
        if (choice == JOptionPane.CLOSED_OPTION) {
            JOptionPane.showMessageDialog(null, "Программа завершена.");
            return;
        }

        // Получение радиуса от пользователя
        double radius = getUserInputDouble("Введите радиус (положительное число):");

        // Выполнение расчета в зависимости от выбора пользователя
        if (choice == 0) {
            double area = Math.PI * radius * radius;
            JOptionPane.showMessageDialog(null, "Площадь круга с радиусом " + radius + " равна " + area);
        } else {
            double circumference = 2 * Math.PI * radius;
            JOptionPane.showMessageDialog(null, "Длина окружности с радиусом " + radius + " равна " + circumference);
        }
    }
}